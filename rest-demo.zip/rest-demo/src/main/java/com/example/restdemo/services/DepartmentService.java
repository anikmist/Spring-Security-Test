package com.example.restdemo.services;

import com.example.restdemo.entities.Department;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface DepartmentService {

    public Department updateDepartment(Department department);

    public Department createDepartment(Department department);

    public List<Department> getAllDepartments();

    public Department getDepartmentById(Long id);

    public void deleteDepartmentById(Long id);

    public Department getDepartmentByName(String name);
}
