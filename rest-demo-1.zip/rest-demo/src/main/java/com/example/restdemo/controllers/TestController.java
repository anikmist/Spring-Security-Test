package com.example.restdemo.controllers;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class TestController {

    @GetMapping("/balance")
    public String accountBalance(){
        return "Balance Amount : 4,50,000.00";
    }

    @GetMapping("/notice")
    public String notices(){
        return "Notice-1  Notice-2  Notice-3 ....!!!";
    }
}
