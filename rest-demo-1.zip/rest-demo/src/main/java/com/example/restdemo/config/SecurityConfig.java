package com.example.restdemo.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

import javax.sql.DataSource;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
          http.authorizeHttpRequests( (auth)-> auth.requestMatchers("/api/balance").authenticated()
                  .requestMatchers("/api/notice","/api/contact").permitAll())
                  .httpBasic(Customizer.withDefaults());
           return http.build();

    }
    /*
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
        http.authorizeHttpRequests( (auth)-> auth.anyRequest().permitAll() )
                .httpBasic(Customizer.withDefaults());
        return http.build();

    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
        http.authorizeHttpRequests( (auth)-> auth.anyRequest().denyAll() )
                .httpBasic(Customizer.withDefaults());
        return http.build();

    }

*/

/*
    @Bean
    public InMemoryUserDetailsManager userDetailsService(){

        PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
        /*
        //Style-1
        UserDetails admin = User.withUsername("admin").password(encoder.encode("12345")).authorities("admin").build();
        UserDetails user  = User.withUsername("user").password(encoder.encode("12345")).authorities("read").build();
        UserDetails base = User.withUsername("base").password(encoder.encode("12345")).roles("USER").build();
        return new InMemoryUserDetailsManager(admin, user, base);


        //Style-2
        InMemoryUserDetailsManager userDetailsService = new InMemoryUserDetailsManager();
        UserDetails admin = User.withUsername("admin").password(encoder.encode("12345")).authorities("admin").build();
        UserDetails user = User.withUsername("user").password(encoder.encode("12345")).authorities("read").build();
        userDetailsService.createUser(admin);
        userDetailsService.createUser(user);
        return userDetailsService;
    }

*/      @Bean
        public UserDetailsService userDetailsService(DataSource dataSource) {
        return new JdbcUserDetailsManager(dataSource);
}
    @Bean
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance();
    }


}
