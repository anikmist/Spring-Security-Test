import com.example.restdemo.entities.Department;
import com.example.restdemo.repositories.DepartmentRepository;
import com.example.restdemo.services.DepartmentService;
import com.example.restdemo.services.DepartmentServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    @PostMapping("/departments")
    public Department createDepartment(@RequestBody Department department){
        return departmentService.createDepartment(department);
    }

    @GetMapping("/departments")
    public List<Department> getAllDepartments(){

        return departmentService.getAllDepartments();
    }

    @GetMapping ("/departments/{id}")
    public Department getDepartmentById(@PathVariable Long id){
        return departmentService.getDepartmentById(id);
    }

    @PutMapping("/departments")
    public Department updateDepartment(@RequestBody Department department){
        return departmentService.updateDepartment(department);
    }

    @DeleteMapping("/departments/{id}")
    public String deleteDepartmentById(@PathVariable Long id){
        departmentService.deleteDepartmentById(id);
        return "id "+id+" Deleted Successfully!!!";
    }

    @GetMapping("/departments/name/{name}")
    public Department getDepartmentByName(@PathVariable String name){
        return departmentService.getDepartmentByName(name);
    }


//    @GetMapping("/departments")
//    public String getHello(){
//        return "hello world!!!";
//    }


}
